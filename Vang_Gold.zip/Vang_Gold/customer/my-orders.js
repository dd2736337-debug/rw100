const BASE_URL = "http://localhost:8080";
const USER_ID = localStorage.getItem("userId");
const TOKEN = localStorage.getItem("token");

$(document).ready(function () {
    if (!TOKEN || !USER_ID) {
        alert("Bạn chưa đăng nhập!");
        window.location.href = "../login.html";
        return;
    }

    $("#username").text(
        "Xin chào, " + (localStorage.getItem("username") || "Khách hàng"),
    );

    loadMyOrders();
});

// ===================
// LOAD ORDERS
// ===================

function loadMyOrders() {
    $("#orderTable").html(`
        <tr>
            <td colspan="5" class="text-center">
                Đang tải dữ liệu...
            </td>
        </tr>
    `);

    $.ajax({
        url: `${BASE_URL}/api/orders/user/${USER_ID}`,
        type: "GET",

        headers: {
            Authorization: "Bearer " + TOKEN,
        },

        success: function (response) {
            renderOrders(response.content || []);
        },

        error: function (xhr) {
            console.log(xhr);

            if (xhr.status === 401) {
                alert("Phiên đăng nhập đã hết hạn!");

                logout();
                return;
            }

            showMessage("Không thể tải danh sách đơn hàng!", "danger");
        },
    });
}

// ===================
// RENDER TABLE
// ===================

function renderOrders(orders) {
    let html = "";

    if (orders.length === 0) {
        html = `
            <tr>
                <td colspan="5" class="text-center">
                    Bạn chưa có đơn hàng nào
                </td>
            </tr>
        `;

        $("#orderTable").html(html);

        return;
    }

    orders.forEach((order) => {
        html += `
            <tr>

                <td>${order.id}</td>

                <td>
                    ${(order.totalPrice || 0).toLocaleString("vi-VN")} VNĐ
                </td>

                <td>
                    <span class="badge ${getStatusColor(order.status)}">
                        ${order.status}
                    </span>
                </td>

                <td>
                    ${
                        order.createdAt
                            ? formatDate(order.createdAt)
                            : "Không có"
                    }
                </td>

                <td>
                    <button
                        class="btn btn-info btn-sm"
                        onclick="viewOrder(${order.id})"
                    >
                        Chi tiết
                    </button>
                </td>

            </tr>
        `;
    });

    $("#orderTable").html(html);
}

// ===================
// VIEW DETAIL
// ===================

function viewOrder(id) {
    $.ajax({
        url: `${BASE_URL}/api/orders/${id}`,
        type: "GET",

        headers: {
            Authorization: "Bearer " + TOKEN,
        },

        success: function (order) {
            let html = "";

            if (!order.orderDetails || order.orderDetails.length === 0) {
                html = `
                    <tr>
                        <td colspan="3" class="text-center">
                            Không có dữ liệu
                        </td>
                    </tr>
                `;
            } else {
                order.orderDetails.forEach((detail) => {
                    html += `
                        <tr>

                            <td>${detail.goldName}</td>

                            <td>${detail.quantity}</td>

                            <td>
                                ${detail.price.toLocaleString("vi-VN")} VNĐ
                            </td>

                        </tr>
                    `;
                });
            }

            $("#detailTable").html(html);

            let modal = new bootstrap.Modal(
                document.getElementById("detailModal"),
            );

            modal.show();
        },

        error: function () {
            alert("Không lấy được chi tiết đơn hàng!");
        },
    });
}

// ===================
// STATUS COLOR
// ===================

function getStatusColor(status) {
    switch (status) {
        case "PENDING":
            return "bg-warning text-dark";

        case "CONFIRMED":
            return "bg-primary";

        case "COMPLETED":
            return "bg-success";

        case "CANCELLED":
            return "bg-danger";

        default:
            return "bg-secondary";
    }
}

// ===================
// FORMAT DATE
// ===================

function formatDate(date) {
    return new Date(date).toLocaleString("vi-VN");
}

// ===================
// MESSAGE
// ===================

function showMessage(message, type) {
    $("#message").html(`
        <div class="alert alert-${type}">
            ${message}
        </div>
    `);
}

// ===================
// LOGOUT
// ===================

function logout() {
    localStorage.clear();

    window.location.href = "../login.html";
}
