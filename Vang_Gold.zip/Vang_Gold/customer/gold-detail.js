const params = new URLSearchParams(window.location.search);

const goldId = params.get("id");

const GOLD_API = "http://localhost:8080/api/golds/";
const ORDER_API = "http://localhost:8080/api/orders";

let currentGold = null;

$(document).ready(function () {
    if (!goldId) {
        alert("Không tìm thấy sản phẩm");
        window.location.href = "home.html";
        return;
    }

    loadGold();

    $("#btnBuy").click(function () {
        buyNow();
    });
});

// ======================
// LOAD GOLD DETAIL
// ======================

function loadGold() {
    $.ajax({
        url: GOLD_API + goldId,
        type: "GET",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        success: function (gold) {
            currentGold = gold;

            if (gold.image) {
                $("#image").attr("src", "http://localhost:8080" + gold.image);
            } else {
                $("#image").attr("src", "https://via.placeholder.com/500");
            }

            $("#name").text(gold.name);

            $("#type").text(gold.type);

            $("#weight").text(gold.weight);

            $("#price").text(
                Number(gold.price).toLocaleString("vi-VN") + " VNĐ",
            );

            $("#category").text(gold.categoryName || "Chưa có");

            $("#quantity").attr("max", gold.quantity);
        },

        error: function () {
            showMessage("Không tải được sản phẩm", "danger");
        },
    });
}

// ======================
// BUY NOW
// ======================

function buyNow() {
    let quantity = Number($("#quantity").val());

    if (quantity <= 0) {
        showMessage("Số lượng phải lớn hơn 0", "danger");
        return;
    }

    if (quantity > currentGold.quantity) {
        showMessage("Số lượng vượt quá tồn kho", "danger");
        return;
    }

    let userId = localStorage.getItem("userId");

    if (!userId) {
        alert("Bạn chưa đăng nhập");

        window.location.href = "../login.html";

        return;
    }

    let order = {
        userId: Number(userId),

        orderDetails: [
            {
                goldId: Number(goldId),

                quantity: quantity,
            },
        ],
    };

    $.ajax({
        url: ORDER_API,

        type: "POST",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        contentType: "application/json",

        data: JSON.stringify(order),

        success: function () {
            showMessage("Đặt hàng thành công!", "success");

            setTimeout(() => {
                window.location.href = "my-orders.html";
            }, 1000);
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            showMessage(xhr.responseText || "Đặt hàng thất bại", "danger");
        },
    });
}

// ======================
// MESSAGE
// ======================

function showMessage(text, type) {
    $("#message").html(`
        <div class="alert alert-${type}">
            ${text}
        </div>
    `);
}
