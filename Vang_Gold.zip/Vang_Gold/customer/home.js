const API = "http://localhost:8080";
const GOLD_URL = API + "/api/golds";
const ORDER_URL = API + "/api/orders";

$(document).ready(function () {
    let token = localStorage.getItem("token");

    if (!token) {
        window.location.href = "../login.html";
        return;
    }

    let username = localStorage.getItem("username");

    $("#welcomeUser").text("Xin chào, " + (username || "Khách hàng"));

    loadGolds();

    $("#searchName").keyup(searchGold);

    $("#quantity").on("input", calculateTotal);
});

function loadGolds() {
    $.ajax({
        url: GOLD_URL + "?page=0&size=100",
        type: "GET",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        success: function (response) {
            console.log("Danh sách Gold:");
            console.log(response.content);

            renderGolds(response.content);
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            if (xhr.status === 401) {
                logout();
            }

            alert("Không tải được danh sách vàng.");
        },
    });
}

function renderGolds(golds) {
    let html = "";

    golds.forEach((gold) => {
        let image = gold.image
            ? API + gold.image
            : "https://via.placeholder.com/300x200";

        html += `
            <div class="col-md-4 mb-4">

                <div class="card shadow h-100">

                    <img
                        src="${image}"
                        style="
                            height:200px;
                            object-fit:cover;
                        "
                    />

                    <div class="card-body">

                        <h5>${gold.name}</h5>

                        <p>
                            <b>Loại:</b>
                            ${gold.type}
                        </p>

                        <p>
                            <b>Khối lượng:</b>
                            ${gold.weight} gram
                        </p>

                        <p>
                            <b>Giá:</b>
                            ${(gold.price || 0).toLocaleString("vi-VN")} VNĐ
                        </p>

                        <p>
                            <b>Tồn kho:</b>
                            ${gold.quantity}
                        </p>

                    </div>

                    <div class="
                            card-footer
                            d-flex
                            justify-content-between">

                        <button
                            class="btn btn-info"
                            onclick="viewDetail(${gold.id})">

                            Chi tiết
                        </button>

                        <button
                            class="btn btn-success"
                            onclick="
                                openBuyModal(
                                    ${gold.id},
                                    '${gold.name}',
                                    ${gold.price},
                                    ${gold.quantity}
                                )
                            ">

                            Mua ngay
                        </button>

                    </div>

                </div>

            </div>
        `;
    });

    $("#goldList").html(html);
}

function searchGold() {
    let keyword = $("#searchName").val().toLowerCase();

    $.ajax({
        url: GOLD_URL,
        type: "GET",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        success: function (response) {
            let result = response.content.filter((gold) =>
                gold.name.toLowerCase().includes(keyword),
            );

            renderGolds(result);
        },
    });
}

function viewDetail(id) {
    window.location.href = "./gold-detail.html?id=" + id;
}

function openBuyModal(id, name, price, stock) {
    $("#goldId").val(id);

    $("#goldName").val(name);

    $("#goldPrice").val(price);

    $("#quantity").val(1);

    $("#goldTotal").val(price);

    $("#quantity").attr("max", stock);

    let modal = new bootstrap.Modal(document.getElementById("buyModal"));

    modal.show();
}

function calculateTotal() {
    let quantity = Number($("#quantity").val());

    let price = Number($("#goldPrice").val());

    $("#goldTotal").val(quantity * price);
}

function buyGold() {
    let quantity = Number($("#quantity").val());

    let max = Number($("#quantity").attr("max"));

    if (quantity <= 0) {
        alert("Số lượng phải lớn hơn 0");

        return;
    }

    if (quantity > max) {
        alert("Số lượng vượt quá tồn kho!");

        return;
    }

    let order = {
        userId: Number(localStorage.getItem("userId")),

        orderDetails: [
            {
                goldId: Number($("#goldId").val()),

                quantity: quantity,
            },
        ],
    };

    $.ajax({
        url: ORDER_URL,

        type: "POST",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        contentType: "application/json",

        data: JSON.stringify(order),

        success: function () {
            alert("Đặt hàng thành công!");

            bootstrap.Modal.getInstance(
                document.getElementById("buyModal"),
            ).hide();

            window.location.href = "my-orders.html";
        },

        error: function (xhr) {
            alert(xhr.responseText || "Đặt hàng thất bại!");
        },
    });
}

function logout() {
    localStorage.clear();

    window.location.href = "../login.html";
}
