const LOGIN_URL = "http://localhost:8080/api/auth/login";

// ======================
// LOGIN
// ======================

function login() {
    let username = $("#username").val().trim();
    let password = $("#password").val().trim();

    // Validate
    if (!username || !password) {
        alert("Vui lòng nhập đầy đủ Username và Password!");
        return;
    }

    let user = {
        username: username,
        password: password,
    };

    $.ajax({
        url: LOGIN_URL,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(user),

        success: function (response) {
            // Lưu thông tin đăng nhập
            localStorage.setItem("token", response.token);
            localStorage.setItem("role", response.role);
            localStorage.setItem("userId", response.userId);

            // Chỉ lưu nếu backend trả về
            if (response.username) {
                localStorage.setItem("username", response.username);
            }

            // Chuyển trang theo quyền
            if (response.role === "ADMIN") {
                window.location.href = "./admin/dashboard.html";
            } else {
                window.location.href = "./customer/home.html";
            }
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            alert("Sai tài khoản hoặc mật khẩu!");
        },
    });
}

// ======================
// ENTER TO LOGIN
// ======================

$(document).keypress(function (e) {
    if (e.which === 13) {
        login();
    }
});

// ======================
// CHECK LOGIN
// ======================

window.onload = function () {
    // Xóa dữ liệu còn sót trên form
    $("#username").val("");
    $("#password").val("");

    let token = localStorage.getItem("token");
    let role = localStorage.getItem("role");

    // Nếu đã đăng nhập thì chuyển thẳng vào hệ thống
    if (token && role) {
        if (role === "ADMIN") {
            window.location.href = "./admin/dashboard.html";
        } else {
            window.location.href = "./customer/home.html";
        }
    }
};
