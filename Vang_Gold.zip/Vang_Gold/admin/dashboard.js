const USER_API = "http://localhost:8080/api/users";
const GOLD_API = "http://localhost:8080/api/golds";
const ORDER_API = "http://localhost:8080/api/orders";

const TOKEN = localStorage.getItem("token");
const ROLE = localStorage.getItem("role");

// =========================
// INIT
// =========================

$(document).ready(function () {
    if (!TOKEN || ROLE !== "ADMIN") {
        alert("Bạn không có quyền truy cập!");

        window.location.href = "../login.html";
        return;
    }

    const username = localStorage.getItem("username");

    $("#adminName").text(username ? `Xin chào ${username}` : "Xin chào ADMIN");

    loadDashboard();
});

// =========================
// LOAD DASHBOARD
// =========================

function loadDashboard() {
    loadUsers();
    loadGolds();
    loadOrders();
}

// =========================
// LOAD USER
// =========================

function loadUsers() {
    $.ajax({
        url: USER_API + "?page=0&size=1",

        type: "GET",

        headers: {
            Authorization: "Bearer " + TOKEN,
        },

        success: function (response) {
            $("#totalUsers").text(response.totalElements || 0);
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            $("#totalUsers").text("0");
        },
    });
}

// =========================
// LOAD GOLD
// =========================

function loadGolds() {
    $.ajax({
        url: GOLD_API + "?page=0&size=1",

        type: "GET",

        headers: {
            Authorization: "Bearer " + TOKEN,
        },

        success: function (response) {
            $("#totalGolds").text(response.totalElements || 0);
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            $("#totalGolds").text("0");
        },
    });
}

// =========================
// LOAD ORDER
// =========================

function loadOrders() {
    $.ajax({
        url: ORDER_API + "?page=0&size=100",

        type: "GET",

        headers: {
            Authorization: "Bearer " + TOKEN,
        },

        success: function (response) {
            const orders = response.content || [];

            $("#totalOrders").text(response.totalElements || 0);

            calculateRevenue(orders);

            renderRecentOrders(orders);
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            $("#totalOrders").text("0");
        },
    });
}

// =========================
// CALCULATE REVENUE
// =========================

function calculateRevenue(orders) {
    let total = 0;

    orders.forEach((order) => {
        if (order.status === "SUCCESS") {
            total += Number(order.totalPrice);
        }
    });

    $("#revenue").text(total.toLocaleString("vi-VN") + " ₫");
}

// =========================
// RECENT ORDERS
// =========================

function renderRecentOrders(orders) {
    let html = "";

    if (orders.length === 0) {
        html = `
            <tr>
                <td colspan="5" class="text-center">
                    Không có dữ liệu
                </td>
            </tr>
        `;

        $("#recentOrders").html(html);
        return;
    }

    orders
        .sort((a, b) => b.id - a.id)
        .slice(0, 5)
        .forEach((order) => {
            let badge = "bg-secondary";

            if (order.status === "SUCCESS") {
                badge = "bg-success";
            } else if (order.status === "PENDING") {
                badge = "bg-warning";
            } else if (order.status === "CANCEL") {
                badge = "bg-danger";
            }

            html += `
                <tr>

                    <td>
                        ${order.id}
                    </td>

                    <td>
                        ${order.user?.username ?? order.username ?? ""}
                    </td>

                    <td>
                        ${Number(order.totalPrice).toLocaleString("vi-VN")} ₫
                    </td>

                    <td>
                        <span class="badge ${badge}">
                            ${order.status}
                        </span>
                    </td>

                    <td>
                        ${
                            order.createdAt
                                ? order.createdAt.replace("T", " ")
                                : ""
                        }
                    </td>

                </tr>
            `;
        });

    $("#recentOrders").html(html);
}

// =========================
// LOGOUT
// =========================

function logout() {
    if (!confirm("Bạn có muốn đăng xuất?")) {
        return;
    }

    localStorage.clear();

    window.location.href = "../login.html";
}
