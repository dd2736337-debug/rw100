const USER_URL = "http://localhost:8080/api/users";

let page = 0;
let size = 5;
let totalPages = 0;

$(document).ready(function () {
    setTimeout(function () {
        $("#searchUsername").val("");
    }, 100);

    loadUsers();
});

$("#searchUsername").on("focus", function () {
    if (this.value === "admin") {
        this.value = "";
    }
});

// ===============================
// TOKEN
// ===============================

function getToken() {
    return localStorage.getItem("token");
}

// ===============================
// LOAD USER
// ===============================

function loadUsers() {
    $.ajax({
        url: USER_URL + "?page=" + page + "&size=" + size,

        type: "GET",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        success: function (response) {
            totalPages = response.totalPages;

            let html = "";

            response.content.forEach((user) => {
                html += `

                <tr>

                    <td>${user.id}</td>

                    <td>${user.username}</td>

                    <td>${user.fullName}</td>

                    <td>${user.email ?? ""}</td>

                    <td>${user.phone}</td>

                    <td>${user.address}</td>

                    <td>
                        <span class="badge bg-primary">
                            ${user.role}
                        </span>
                    </td>


                    <td>

                        <button 
                            class="btn btn-warning btn-sm"
                            onclick="editUser(${user.id})">

                            Sửa

                        </button>


                        <button 
                            class="btn btn-danger btn-sm"
                            onclick="deleteUser(${user.id})">

                            Xóa

                        </button>


                    </td>


                </tr>

                `;
            });

            $("#userTable").html(html);

            buildPagination(response);
        },

        error: function (xhr) {
            console.log(xhr.responseText);
        },
    });
}

// ===============================
// OPEN CREATE MODAL
// ===============================

function openCreateModal() {
    resetForm();

    $("#modalTitle").text("Thêm User");

    $("#username").prop("disabled", false);

    $("#password").prop("disabled", false);

    let modal = new bootstrap.Modal(document.getElementById("userModal"));

    modal.show();
}

// ===============================
// SAVE CREATE + UPDATE
// ===============================

function saveUser() {
    let id = $("#id").val();

    let user;

    // CREATE

    if (!id) {
        user = {
            username: $("#username").val(),

            password: $("#password").val(),

            fullName: $("#fullName").val(),

            email: $("#email").val(),

            phone: $("#phone").val(),

            address: $("#address").val(),

            role: $("#role").val(),
        };
    }

    // UPDATE
    else {
        user = {
            fullName: $("#fullName").val(),

            email: $("#email").val(),

            phone: $("#phone").val(),

            address: $("#address").val(),

            role: $("#role").val(),
        };
    }

    let method = id ? "PUT" : "POST";

    let url = id ? USER_URL + "/" + id : USER_URL;

    $.ajax({
        url: url,

        type: method,

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        contentType: "application/json",

        data: JSON.stringify(user),

        success: function () {
            alert(id ? "Sửa thành công" : "Thêm thành công");

            let modal = bootstrap.Modal.getInstance(
                document.getElementById("userModal"),
            );

            modal.hide();

            resetForm();

            loadUsers();
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            alert("Lưu thất bại");
        },
    });
}

// ===============================
// EDIT
// ===============================

function editUser(id) {
    $.ajax({
        url: USER_URL + "/" + id,

        type: "GET",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        success: function (user) {
            $("#modalTitle").text("Sửa User");

            $("#id").val(user.id);

            $("#username").val(user.username).prop("disabled", true);

            $("#password").val("").prop("disabled", true);

            $("#fullName").val(user.fullName);

            $("#email").val(user.email);

            $("#phone").val(user.phone);

            $("#address").val(user.address);

            $("#role").val(user.role);

            let modal = new bootstrap.Modal(
                document.getElementById("userModal"),
            );

            modal.show();
        },
    });
}

// ===============================
// DELETE
// ===============================

function deleteUser(id) {
    if (!confirm("Bạn có chắc muốn xóa User?")) {
        return;
    }

    $.ajax({
        url: USER_URL + "/" + id,

        type: "DELETE",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        success: function () {
            alert("Xóa thành công");

            loadUsers();
        },
    });
}

// ===============================
// PAGINATION
// ===============================

function buildPagination(response) {
    let html = "";

    html += `


    <li class="page-item ${response.first ? "disabled" : ""}">

        <button class="page-link"
        onclick="changePage(${page - 1})">

            Trước

        </button>


    </li>


    `;

    for (let i = 0; i < response.totalPages; i++) {
        html += `


        <li class="page-item ${i === page ? "active" : ""}">


            <button class="page-link"
            onclick="changePage(${i})">

                ${i + 1}

            </button>


        </li>


        `;
    }

    html += `


    <li class="page-item ${response.last ? "disabled" : ""}">


        <button class="page-link"
        onclick="changePage(${page + 1})">

            Sau

        </button>


    </li>


    `;

    $("#pagination").html(html);
}

function changePage(number) {
    if (number === page) {
        return;
    }
    if (number < 0 || number >= totalPages) {
        return;
    }

    page = number;

    loadUsers();
}

// ===============================
// RESET FORM
// ===============================

function resetForm() {
    $("#id").val("");

    $("#username").val("");

    $("#password").val("");

    $("#fullName").val("");

    $("#email").val("");

    $("#phone").val("");

    $("#address").val("");

    $("#role").val("CUSTOMER");
}

// ===============================
// SEARCH USER
// ===============================

function searchUser() {
    let username = $("#searchUsername").val();
    let email = $("#searchEmail").val();
    let fullName = $("#searchFullName").val();

    page = 0;

    $.ajax({
        url:
            USER_URL +
            "?page=" +
            page +
            "&size=" +
            size +
            "&username=" +
            username +
            "&email=" +
            email +
            "&fullName=" +
            fullName,

        type: "GET",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        success: function (response) {
            totalPages = response.totalPages;

            let html = "";

            response.content.forEach((user) => {
                html += `

                <tr>

                    <td>${user.id}</td>

                    <td>${user.username}</td>

                    <td>${user.fullName}</td>

                    <td>${user.email ?? ""}</td>

                    <td>${user.phone ?? ""}</td>

                    <td>${user.address ?? ""}</td>

                    <td>
                        <span class="badge bg-primary">
                            ${user.role}
                        </span>
                    </td>

                    <td>

                        <button 
                        class="btn btn-warning btn-sm"
                        onclick="editUser(${user.id})">
                            Sửa
                        </button>


                        <button 
                        class="btn btn-danger btn-sm"
                        onclick="deleteUser(${user.id})">
                            Xóa
                        </button>

                    </td>

                </tr>

                `;
            });

            $("#userTable").html(html);

            buildPagination(response);
        },

        error: function (xhr) {
            console.log(xhr.responseText);
        },
    });
}
