const ORDER_URL = "http://localhost:8080/api/orders";

let page = 0;
let size = 5;
let totalPages = 0;

let searchUsername = "";
let searchStatus = "";

// ==============================
// INIT
// ==============================

$(document).ready(function () {
    loadOrders();
});

// ==============================
// TOKEN
// ==============================

function getToken() {
    return localStorage.getItem("token");
}

// ==============================
// LOAD ORDERS
// ==============================

function loadOrders() {
    let url = ORDER_URL + "?page=" + page + "&size=" + size;

    if (searchUsername) {
        url += "&username=" + encodeURIComponent(searchUsername);
    }

    if (searchStatus) {
        url += "&status=" + searchStatus;
    }

    $.ajax({
        url: url,

        method: "GET",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        success: function (response) {
            totalPages = response.totalPages;

            renderOrders(response.content);

            renderPagination(response);
        },

        error: function (xhr) {
            console.log(xhr.status);

            console.log(xhr.responseText);

            showToast("Không tải được đơn hàng", "error");
        },
    });
}

// ==============================
// RENDER TABLE
// ==============================

function renderOrders(orders) {
    let html = "";

    if (orders.length === 0) {
        html = `

        <tr>

            <td colspan="7"
            class="text-center text-muted">

            Không có đơn hàng

            </td>

        </tr>

        `;

        $("#orderTable").html(html);

        return;
    }

    orders.forEach((order) => {
        html += `


        <tr>


            <td>

                #${order.id}

            </td>



            <td>

                ${order.username ?? ""}

            </td>



            <td>

                ${order.fullName ?? ""}

            </td>




            <td class="money">

                ${formatMoney(order.totalPrice)}

            </td>




            <td>

                ${formatDate(order.createdAt)}

            </td>




            <td>

                ${statusBadge(order.status)}

            </td>





            <td class="action-btn">


                <button

                class="btn btn-info btn-sm"

                onclick="viewDetail(${order.id})">


                <i class="fa fa-eye"></i>

                Chi tiết


                </button>



                ${statusButton(order)}



            </td>


        </tr>



        `;
    });

    $("#orderTable").html(html);
}

// ==============================
// STATUS BADGE
// ==============================

function statusBadge(status) {
    let map = {
        PENDING: ["warning", "Chờ xác nhận"],

        CONFIRMED: ["primary", "Đã xác nhận"],

        SHIPPING: ["info", "Đang giao"],

        SUCCESS: ["success", "Hoàn thành"],

        CANCEL: ["danger", "Đã hủy"],
    };

    let item = map[status];

    if (!item) {
        return `

        <span class="badge bg-secondary">

        Không rõ

        </span>

        `;
    }

    return `

    <span class="badge bg-${item[0]}">

        ${item[1]}

    </span>

    `;
}

// ==============================
// ACTION BUTTON
// ==============================

function statusButton(order) {
    if (order.status === "PENDING") {
        return `


        <button

        class="btn btn-primary btn-sm"

        onclick="updateStatus(
        ${order.id},
        'CONFIRMED'
        )">


        Xác nhận


        </button>



        <button

        class="btn btn-danger btn-sm"

        onclick="updateStatus(
        ${order.id},
        'CANCEL'
        )">


        Hủy


        </button>


        `;
    }

    if (order.status === "CONFIRMED") {
        return `


        <button

        class="btn btn-info btn-sm"

        onclick="updateStatus(
        ${order.id},
        'SHIPPING'
        )">


        Giao hàng


        </button>


        `;
    }

    if (order.status === "SHIPPING") {
        return `


        <div class="form-check">


        <input

        class="form-check-input"

        type="checkbox"

        onclick="updateStatus(
        ${order.id},
        'SUCCESS'
        )">


        <label class="form-check-label text-success">


        Đã giao thành công


        </label>



        </div>


        `;
    }

    if (order.status === "SUCCESS") {
        return `


        <span class="text-success fw-bold">

        <i class="fa fa-check"></i>

        Hoàn tất


        </span>


        `;
    }

    return "";
}

// ==============================
// UPDATE STATUS
// ==============================

function updateStatus(id, status) {
    $.ajax({
        url: ORDER_URL + "/" + id,

        method: "PUT",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        contentType: "application/json",

        data: JSON.stringify({
            status: status,
        }),

        success: function () {
            showToast(
                "Cập nhật trạng thái thành công",

                "success",
            );

            loadOrders();
        },

        error: function (xhr) {
            console.log(xhr.status);

            console.log(xhr.responseText);

            showToast(
                "Cập nhật thất bại",

                "error",
            );
        },
    });
}

// ==============================
// VIEW DETAIL
// ==============================

function viewDetail(id) {
    $.ajax({
        url: ORDER_URL + "/" + id,

        method: "GET",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        success: function (order) {
            let html = `



<h5>

Đơn hàng #${order.id}

</h5>



<p>

Khách hàng:

<b>${order.fullName}</b>

</p>



<table class="table">


<thead>

<tr>

<th>Sản phẩm</th>

<th>Ảnh</th>

<th>Số lượng</th>

<th>Giá</th>


</tr>


</thead>


<tbody>



`;

            order.orderDetails.forEach((item) => {
                html += `


<tr>


<td>

${item.goldName}

</td>



<td>


<img

src="${item.goldImage}"

width="60"

class="rounded">


</td>



<td>

${item.quantity}

</td>



<td>

${formatMoney(item.price)}

</td>



</tr>



`;
            });

            html += `


</tbody>

</table>



<h5 class="text-danger">

Tổng:

${formatMoney(order.totalPrice)}

</h5>


`;

            $("#orderDetailContent").html(html);

            new bootstrap.Modal(document.getElementById("detailModal")).show();
        },
    });
}

// ==============================
// SEARCH
// ==============================

function searchOrder() {
    searchUsername = $("#searchUsername").val().trim();

    searchStatus = $("#searchStatus").val();

    page = 0;

    loadOrders();
}

// ==============================
// PAGINATION
// ==============================

function renderPagination(response) {
    let html = "";

    html += `

<li class="page-item 
${response.first ? "disabled" : ""}">


<button class="page-link"

onclick="changePage(${page - 1})">


Trước


</button>


</li>


`;

    for (let i = 0; i < response.totalPages; i++) {
        html += `

<li class="page-item 
${i === page ? "active" : ""}">


<button class="page-link"

onclick="changePage(${i})">


${i + 1}


</button>


</li>


`;
    }

    html += `

<li class="page-item 
${response.last ? "disabled" : ""}">


<button class="page-link"

onclick="changePage(${page + 1})">


Sau


</button>


</li>


`;

    $("#pagination").html(html);
}

function changePage(number) {
    if (number === page) return;

    if (number < 0 || number >= totalPages) return;

    page = number;

    loadOrders();
}

// ==============================
// FORMAT
// ==============================

function formatMoney(value) {
    return new Intl.NumberFormat("vi-VN").format(value) + " VNĐ";
}

function formatDate(value) {
    if (!value) return "";

    return new Date(value).toLocaleString("vi-VN");
}

// ==============================
// TOAST
// ==============================

function showToast(message, type) {
    let toast = $("#toastMessage");

    toast.removeClass("bg-success bg-danger bg-warning");

    if (type === "success") toast.addClass("bg-success");

    if (type === "error") toast.addClass("bg-danger");

    if (type === "warning") toast.addClass("bg-warning");

    $("#toastContent").text(message);

    new bootstrap.Toast(document.getElementById("toastMessage")).show();
}
