const GOLD_API = "http://localhost:8080/api/golds";

let currentPage = 0;
let pageSize = 5;
let totalPages = 0;

// ================= TOKEN =================

function getToken() {
    return localStorage.getItem("token");
}

// ================= LOAD GOLD =================

function loadGolds(page = 0) {
    currentPage = page;

    let name = document.getElementById("searchName").value;

    let type = document.getElementById("searchType").value;

    let url = `${GOLD_API}?page=${page}&size=${pageSize}`;

    if (name) {
        url += `&name=${name}`;
    }

    if (type) {
        url += `&type=${type}`;
    }

    fetch(url, {
        headers: {
            Authorization: "Bearer " + getToken(),
        },
    })
        .then((res) => res.json())

        .then((data) => {
            renderGold(data.content);

            totalPages = data.totalPages;

            renderPagination();
        })

        .catch((err) => console.log(err));
}

// ================= TABLE =================

function renderGold(list) {
    let tbody = document.getElementById("goldTable");

    tbody.innerHTML = "";

    list.forEach((gold) => {
        let image = gold.image
            ? "http://localhost:8080" + gold.image
            : "https://via.placeholder.com/70";

        tbody.innerHTML += `


        <tr>

            <td>${gold.id}</td>


            <td>
                <img 
                src="${image}"
                class="gold-image">
            </td>


            <td>${gold.name}</td>


            <td>${gold.type}</td>


            <td>${gold.weight}</td>


            <td>
            ${gold.price.toLocaleString()} VNĐ
            </td>


            <td>${gold.quantity}</td>


            <td>${gold.categoryName ?? ""}</td>



            <td>


            <button
            class="btn btn-warning btn-sm"
            onclick="editGold(${gold.id})">

            Sửa

            </button>



            <button
            class="btn btn-danger btn-sm"
            onclick="deleteGold(${gold.id})">

            Xóa

            </button>


            </td>


        </tr>


        `;
    });
}

// ================= PAGINATION =================

function renderPagination() {
    let ul = document.getElementById("pagination");

    ul.innerHTML = "";

    for (let i = 0; i < totalPages; i++) {
        ul.innerHTML += `


<li class="page-item">

<button 
class="page-link"
onclick="loadGolds(${i})">

${i + 1}

</button>

</li>


`;
    }
}

// ================= RESET FORM =================

function resetForm() {
    document.getElementById("goldId").value = "";

    document.getElementById("name").value = "";

    document.getElementById("type").value = "";

    document.getElementById("weight").value = "";

    document.getElementById("price").value = "";

    document.getElementById("quantity").value = "0";

    document.getElementById("image").value = "";

    document.getElementById("previewImage").style.display = "none";

    document.getElementById("modalTitle").innerHTML = "Thêm Gold";
}

// ================= SAVE =================

function saveGold() {
    let id = document.getElementById("goldId").value;

    if (id) {
        updateGold(id);
    } else {
        createGold();
    }
}

// ================= CREATE =================

function createGold() {
    let formData = new FormData();

    appendForm(formData);

    fetch(GOLD_API, {
        method: "POST",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        body: formData,
    }).then((res) => {
        if (res.ok) {
            alert("Thêm thành công");

            loadGolds();
        } else {
            alert("Lỗi thêm");
        }
    });
}

// ================= UPDATE =================

function updateGold(id) {
    let formData = new FormData();

    appendForm(formData);

    fetch(`${GOLD_API}/${id}`, {
        method: "PUT",

        headers: {
            Authorization: "Bearer " + getToken(),
        },

        body: formData,
    }).then((res) => {
        if (res.ok) {
            alert("Cập nhật thành công");

            loadGolds();
        }
    });
}

// ================= FORM DATA =================

function appendForm(formData) {
    formData.append("name", document.getElementById("name").value);

    formData.append("type", document.getElementById("type").value);

    formData.append("weight", document.getElementById("weight").value);

    formData.append("price", document.getElementById("price").value);

    formData.append("quantity", document.getElementById("quantity").value);

    formData.append("categoryId", document.getElementById("categoryId").value);

    let file = document.getElementById("image").files[0];

    if (file) {
        formData.append("image", file);
    }
}

// ================= EDIT =================

function editGold(id) {
    fetch(`${GOLD_API}/${id}`, {
        headers: {
            Authorization: "Bearer " + getToken(),
        },
    })
        .then((res) => res.json())

        .then((gold) => {
            document.getElementById("goldId").value = gold.id;

            document.getElementById("name").value = gold.name;

            document.getElementById("type").value = gold.type;

            document.getElementById("weight").value = gold.weight;

            document.getElementById("price").value = gold.price;

            document.getElementById("quantity").value = gold.quantity;

            document.getElementById("categoryId").value = gold.categoryId;

            document.getElementById("modalTitle").innerHTML = "Cập nhật Gold";

            new bootstrap.Modal(document.getElementById("goldModal")).show();
        });
}

// ================= DELETE =================

function deleteGold(id) {
    if (!confirm("Xóa sản phẩm này?")) return;

    fetch(`${GOLD_API}/${id}`, {
        method: "DELETE",

        headers: {
            Authorization: "Bearer " + getToken(),
        },
    }).then((res) => {
        if (res.ok) {
            alert("Xóa thành công");

            loadGolds(currentPage);
        }
    });
}

// ================= IMAGE PREVIEW =================

document.getElementById("image").addEventListener("change", function () {
    let file = this.files[0];

    if (file) {
        let img = document.getElementById("previewImage");

        img.src = URL.createObjectURL(file);

        img.style.display = "block";
    }
});

// ================= START =================

document.addEventListener("DOMContentLoaded", () => {
    loadGolds();
});
