const CATEGORY_URL = "http://localhost:8080/api/categories";

let page = 0;
let size = 5;
let totalPages = 0;

$(document).ready(function () {
    checkLogin();

    loadCategories();
});

// =======================
// CHECK LOGIN
// =======================

function checkLogin() {
    let token = localStorage.getItem("token");

    if (!token) {
        alert("Bạn chưa đăng nhập!");

        window.location.href = "../login.html";
    }
}

// =======================
// LOAD CATEGORY
// =======================

function loadCategories() {
    let name = $("#searchName").val() || "";

    $.ajax({
        url: CATEGORY_URL + "?page=" + page + "&size=" + size,

        type: "GET",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        success: function (response) {
            totalPages = response.totalPages;

            let html = "";

            if (response.content.length === 0) {
                html = `
                    <tr>
                        <td colspan="3"
                            class="text-center">
                            Không có dữ liệu
                        </td>
                    </tr>
                `;
            }

            response.content.forEach((category) => {
                if (category.name.toLowerCase().includes(name.toLowerCase())) {
                    html += `
                        <tr>

                            <td>${category.id}</td>

                            <td>${category.name}</td>

                            <td>

                                <button
                                    class="btn btn-warning btn-sm"
                                    onclick="editCategory(${category.id})">

                                    Sửa

                                </button>

                                <button
                                    class="btn btn-danger btn-sm"
                                    onclick="deleteCategory(${category.id})">

                                    Xóa

                                </button>

                            </td>

                        </tr>
                    `;
                }
            });

            $("#categoryTable").html(html);

            buildPagination(response);
        },

        error: function (xhr) {
            if (xhr.status === 401) {
                alert("Phiên đăng nhập hết hạn!");

                logout();
            }

            console.log(xhr.responseText);
        },
    });
}

// =======================
// CREATE + UPDATE
// =======================

function saveCategory() {
    $("#nameError").text("");

    let id = $("#categoryId").val();

    let name = $("#name").val().trim();

    if (name === "") {
        $("#nameError").text("Tên Category không được để trống");

        return;
    }

    let category = {
        name: name,
    };

    let method = "POST";

    let url = CATEGORY_URL;

    if (id) {
        method = "PUT";

        url = CATEGORY_URL + "/" + id;
    }

    $.ajax({
        url: url,

        type: method,

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        contentType: "application/json",

        data: JSON.stringify(category),

        success: function () {
            alert(id ? "Sửa thành công" : "Thêm thành công");

            bootstrap.Modal.getInstance(
                document.getElementById("categoryModal"),
            ).hide();

            resetForm();

            loadCategories();
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            alert("Lưu thất bại!");
        },
    });
}

// =======================
// FIND BY ID
// =======================

function editCategory(id) {
    $.ajax({
        url: CATEGORY_URL + "/" + id,

        type: "GET",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        success: function (category) {
            $("#categoryId").val(category.id);

            $("#name").val(category.name);

            new bootstrap.Modal(
                document.getElementById("categoryModal"),
            ).show();
        },
    });
}

// =======================
// DELETE
// =======================

function deleteCategory(id) {
    if (!confirm("Bạn có chắc muốn xóa?")) {
        return;
    }

    $.ajax({
        url: CATEGORY_URL + "/" + id,

        type: "DELETE",

        headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
        },

        success: function () {
            alert("Xóa thành công!");

            if (page > 0) {
                page--;
            }

            loadCategories();
        },

        error: function (xhr) {
            console.log(xhr.responseText);

            alert("Xóa thất bại!");
        },
    });
}

// =======================
// PAGINATION
// =======================

function buildPagination(response) {
    let html = "";

    html += `
        <li class="page-item
            ${response.first ? "disabled" : ""}
        ">
            <button
                class="page-link"
                onclick="changePage(${page - 1})">

                Trước

            </button>
        </li>
    `;

    for (let i = 0; i < response.totalPages; i++) {
        html += `
            <li class="page-item
                ${i === page ? "active" : ""}
            ">

                <button
                    class="page-link"
                    onclick="changePage(${i})">

                    ${i + 1}

                </button>

            </li>
        `;
    }

    html += `
        <li class="page-item
            ${response.last ? "disabled" : ""}
        ">
            <button
                class="page-link"
                onclick="changePage(${page + 1})">

                Sau

            </button>
        </li>
    `;

    $("#pagination").html(html);
}

function changePage(number) {
    if (number < 0 || number >= totalPages) {
        return;
    }

    page = number;

    loadCategories();
}

// =======================
// SEARCH
// =======================

function searchCategory() {
    page = 0;

    loadCategories();
}

function resetSearch() {
    $("#searchName").val("");

    page = 0;

    loadCategories();
}

// =======================
// RESET FORM
// =======================

function resetForm() {
    $("#categoryId").val("");

    $("#name").val("");

    $("#nameError").text("");
}

// =======================
// LOGOUT
// =======================

function logout() {
    localStorage.clear();

    window.location.href = "../login.html";
}
