const REGISTER_URL = "http://localhost:8080/api/auth/register";

// ======================
// REGISTER
// ======================

function register() {
    const user = {
        username: $("#username").val().trim(),
        password: $("#password").val().trim(),
        fullName: $("#fullName").val().trim(),
        email: $("#email").val().trim(),
        phone: $("#phone").val().trim(),
        address: $("#address").val().trim(),
        role: "CUSTOMER",
    };

    // ======================
    // Validate bắt buộc
    // ======================

    if (
        !user.username ||
        !user.password ||
        !user.fullName ||
        !user.email ||
        !user.phone ||
        !user.address
    ) {
        alert("Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    // ======================
    // Validate Password
    // ======================

    if (user.password.length < 6) {
        alert("Mật khẩu phải có ít nhất 6 ký tự!");
        return;
    }

    // Password phải có cả chữ và số
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d).{6,}$/;

    if (!passwordRegex.test(user.password)) {
        alert("Mật khẩu phải chứa cả chữ và số!");
        return;
    }

    // ======================
    // Validate Email
    // ======================

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(user.email)) {
        alert("Email không hợp lệ!");
        return;
    }

    // ======================
    // Validate Phone
    // ======================

    const phoneRegex = /^0\d{9}$/;

    if (!phoneRegex.test(user.phone)) {
        alert("Số điện thoại phải gồm 10 chữ số và bắt đầu bằng số 0!");
        return;
    }

    // ======================
    // CALL API
    // ======================

    $.ajax({
        url: REGISTER_URL,
        type: "POST",
        contentType: "application/json",
        data: JSON.stringify(user),

        success: function () {
            alert("Đăng ký thành công!");

            // Xóa dữ liệu trên form
            $("#username").val("");
            $("#password").val("");
            $("#fullName").val("");
            $("#email").val("");
            $("#phone").val("");
            $("#address").val("");

            // Chuyển về trang đăng nhập
            window.location.href = "./login.html";
        },

        error: function (xhr) {
            console.log(xhr);

            let message = "Đăng ký thất bại!";

            if (xhr.responseJSON?.message) {
                message = xhr.responseJSON.message;
            } else if (xhr.responseText) {
                message = xhr.responseText;
            }

            alert(message);
        },
    });
}

// ======================
// ENTER TO REGISTER
// ======================

$(document).ready(function () {
    $("input").keypress(function (e) {
        if (e.which === 13) {
            register();
        }
    });
});

// ======================
// PAGE INIT
// ======================

window.onload = function () {
    $("#username").val("");
    $("#password").val("");
    $("#fullName").val("");
    $("#email").val("");
    $("#phone").val("");
    $("#address").val("");
};
