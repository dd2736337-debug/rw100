package com.vti.gold.service.Impl;

import com.vti.gold.Specification.GoldSpecification;
import com.vti.gold.dto.GoldDTO;
import com.vti.gold.entity.Category;
import com.vti.gold.entity.Gold;
import com.vti.gold.form.GoldCreateForm;
import com.vti.gold.form.GoldUpdateForm;
import com.vti.gold.repository.CategoryRepository;
import com.vti.gold.repository.GoldRepository;
import com.vti.gold.repository.OrderDetailRepository;
import com.vti.gold.service.IGoldService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
public class GoldServiceImpl implements IGoldService {

    @Autowired
    private GoldRepository goldRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ModelMapper modelMapper;

    // Tiêm đường dẫn lưu file từ application.properties
    @Value("${app.file.upload-dir:uploads/}")
    private String uploadDir;

    private OrderDetailRepository orderDetailRepository;

    @Override
    public Page<GoldDTO> findAll(String name, String type, Pageable pageable) {
        Specification<Gold> specification = Specification.allOf(GoldSpecification.hasName(name), GoldSpecification.hasType(type));

        return goldRepository.findAll(specification, pageable).map(this::convertToDTO);
    }

    @Override
    public GoldDTO findById(Integer id) {
        Gold gold = goldRepository.findById(id).orElseThrow(() -> new RuntimeException("Gold not found!"));
        return convertToDTO(gold);
    }

    @Override
    @Transactional
    public GoldDTO create(GoldCreateForm form) {
        Category category = categoryRepository.findById(form.getCategoryId()).orElseThrow(() -> new RuntimeException("Category not found!"));

        Gold gold = new Gold();
        gold.setName(form.getName());
        gold.setType(form.getType());
        gold.setWeight(form.getWeight());
        gold.setPrice(form.getPrice());
        gold.setQuantity(form.getQuantity());
        gold.setCategory(category);

        // Lưu ảnh và lưu URL vào DB
        if (form.getImage() != null && !form.getImage().isEmpty()) {
            gold.setImage(saveImage(form.getImage()));
        }

        Gold savedGold = goldRepository.save(gold);
        return convertToDTO(savedGold);
    }

    @Override
    @Transactional
    public GoldDTO update(Integer id, GoldUpdateForm form) {

        Gold gold = goldRepository.findById(id).orElseThrow(() -> new RuntimeException("Gold not found"));

        Category category = categoryRepository.findById(form.getCategoryId()).orElseThrow(() -> new RuntimeException("Category not found"));

        gold.setName(form.getName());
        gold.setType(form.getType());
        gold.setWeight(form.getWeight());
        gold.setPrice(form.getPrice());
        gold.setQuantity(form.getQuantity());
        gold.setCategory(category);

        if (form.getImage() != null && !form.getImage().isEmpty()) {
            gold.setImage(saveImage(form.getImage()));
        }

        Gold saved = goldRepository.save(gold);

        return convertToDTO(saved);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        if (orderDetailRepository.existsByGold_Id(id)) {
            throw new RuntimeException("Không thể xóa vàng đã tồn tại trong đơn hàng.");
        }
        Gold gold = goldRepository.findById(id).orElseThrow(() -> new RuntimeException("Gold not found!"));

        goldRepository.delete(gold);
    }

    // --- Phương thức xử lý File ảnh ---

    private String saveImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return null;
        }

        if (!isImage(file)) {
            throw new RuntimeException("File phải là ảnh hợp lệ (jpg, jpeg, png)");
        }


        try {
            File folder = new File(uploadDir);
            if (!folder.exists()) {
                folder.mkdirs();
            }

            String originalName = StringUtils.cleanPath(file.getOriginalFilename() != null ? file.getOriginalFilename() : "image.jpg");
            String fileName = UUID.randomUUID() + "_" + originalName;

            Path path = Paths.get(uploadDir).resolve(fileName);
            Files.write(path, file.getBytes());

            // Đồng bộ đường dẫn trả về khớp với thư mục lưu file
            return "/uploads/" + fileName;

        } catch (IOException e) {
            throw new RuntimeException("Không thể lưu file ảnh: " + e.getMessage());
        }
    }

    private boolean isImage(MultipartFile file) {
        String contentType = file.getContentType();
        return contentType != null && (contentType.equals("image/jpeg") || contentType.equals("image/png") || contentType.equals("image/jpg"));
    }

    private GoldDTO convertToDTO(Gold gold) {
        GoldDTO dto = modelMapper.map(gold, GoldDTO.class);
        if (gold.getCategory() != null) {
            dto.setCategoryId(gold.getCategory().getId());
            dto.setCategoryName(gold.getCategory().getName());
        }
        return dto;
    }
}