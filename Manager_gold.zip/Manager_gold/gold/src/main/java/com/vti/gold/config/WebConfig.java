package com.vti.gold.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.nio.file.Paths;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    // Lấy đường dẫn lưu file từ application.properties
    @Value("${app.file.upload-dir:uploads/}")
    private String uploadDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Chuyển đổi đường dẫn tương đối sang đường dẫn tuyệt đối dạng URI chuẩn
        String uploadPath = Paths.get(uploadDir).toAbsolutePath().toUri().toString();

        // 1. Cấu hình cho đường dẫn /uploads/** (Đồng bộ với GoldServiceImpl)
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations(uploadPath);

        // 2. Dự phòng: Nếu DB của bạn đang lưu cả dạng /images/** thì mở thêm mapping này
        registry.addResourceHandler("/images/**")
                .addResourceLocations(uploadPath);
    }
}