package com.vti.gold.security;


import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;


@Component
public class JwtTokenProvider {


    @Value("${jwt.secret}")
    private String secret;


    @Value("${jwt.expiration}")
    private long expiration;


    private SecretKey getSigningKey() {

        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));

    }


    public String generateToken(String username, String role) {

        Date now = new Date();


        Date expiryDate = new Date(now.getTime() + expiration);


        return Jwts.builder()

                .setSubject(username)

                .claim("role", role)

                .setIssuedAt(now)

                .setExpiration(expiryDate)

                .signWith(getSigningKey(), SignatureAlgorithm.HS256)

                .compact();

    }


    public String getUsernameFromToken(String token) {

        Claims claims = Jwts.parserBuilder()

                .setSigningKey(getSigningKey())

                .build()

                .parseClaimsJws(token)

                .getBody();


        return claims.getSubject();

    }


    public String getRoleFromToken(String token) {

        Claims claims = Jwts.parserBuilder()

                .setSigningKey(getSigningKey())

                .build()

                .parseClaimsJws(token)

                .getBody();


        return claims.get("role", String.class);

    }


    public boolean validateToken(String token) {

        try {

            Jwts.parserBuilder()

                    .setSigningKey(getSigningKey())

                    .build()

                    .parseClaimsJws(token);


            return true;


        } catch (ExpiredJwtException e) {
            System.out.println("Token hết hạn");
        } catch (MalformedJwtException e) {
            System.out.println("Token không hợp lệ");
        } catch (SignatureException e) {
            System.out.println("Sai chữ ký");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return false;

    }

}