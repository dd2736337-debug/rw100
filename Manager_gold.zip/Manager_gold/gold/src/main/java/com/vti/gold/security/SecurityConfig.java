package com.vti.gold.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
public class SecurityConfig {

    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;


    // Mã hóa password

    @Bean
    public PasswordEncoder passwordEncoder() {

        return new BCryptPasswordEncoder();

    }


    // Security + JWT

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {


        http


                // bật CORS

                .cors(cors -> {
                })


                // REST API không dùng CSRF

                .csrf(csrf -> csrf.disable())


                // JWT không dùng session

                .sessionManagement(session ->

                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)

                )


                // phân quyền

                .authorizeHttpRequests(auth -> auth

                        .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()

                        .requestMatchers("/api/auth/**").permitAll()

                        .requestMatchers("/uploads/**").permitAll()


                        // Gold
                        .requestMatchers(HttpMethod.GET, "/api/golds/**").hasAnyRole("ADMIN", "CUSTOMER")

                        .requestMatchers(HttpMethod.POST, "/api/golds/**").hasRole("ADMIN")


                        .requestMatchers(HttpMethod.PUT, "/api/golds/**").hasRole("ADMIN")


                        .requestMatchers(HttpMethod.DELETE, "/api/golds/**").hasRole("ADMIN")


                        // Order
                        .requestMatchers(HttpMethod.GET, "/api/orders/**").hasAnyRole("ADMIN", "CUSTOMER")


                        .requestMatchers(HttpMethod.POST, "/api/orders/**").hasAnyRole("ADMIN", "CUSTOMER")


                        .requestMatchers(HttpMethod.PUT, "/api/orders/**").hasRole("ADMIN")


                        .requestMatchers(HttpMethod.DELETE, "/api/orders/**").hasRole("ADMIN")


                        .anyRequest().authenticated())


                // JWT filter

                .addFilterBefore(

                        jwtAuthenticationFilter,

                        UsernamePasswordAuthenticationFilter.class

                );


        return http.build();

    }


    // CORS config cho Frontend

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {


        CorsConfiguration configuration = new CorsConfiguration();


        configuration.setAllowedOrigins(

                List.of(

                        "http://127.0.0.1:5501",

                        "http://localhost:5501"

                )

        );


        configuration.setAllowedMethods(

                List.of(

                        "GET",

                        "POST",

                        "PUT",

                        "DELETE",

                        "OPTIONS"

                )

        );


        configuration.setAllowedHeaders(

                List.of("*")

        );


        configuration.setAllowCredentials(true);


        UrlBasedCorsConfigurationSource source =

                new UrlBasedCorsConfigurationSource();


        source.registerCorsConfiguration(

                "/**",

                configuration

        );


        return source;

    }

    // AuthenticationManager cho Login

    @Bean
    public AuthenticationManager authenticationManager(

            AuthenticationConfiguration configuration

    ) throws Exception {


        return configuration.getAuthenticationManager();

    }
}
